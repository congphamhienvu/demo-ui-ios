//
//  ContentView.swift
//  ui-kit-demo
//
//  Created by Phạm Công on 11/09/2023.
//

import SwiftUI

fileprivate struct ContentView: View {
    fileprivate func popupError() -> some View {
        return VStack{
            Image("warning_icon")
                .frame(width: 40, height: 40)
            Text("Lưu thông tin không thành công!")
                .font(
                    Font.custom("Averta", size: 18)
                        .weight(.bold)
                )
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.95, green: 0.13, blue: 0.13))
                .padding(.top, 20)
            Text("Vui lòng thử lại!")
                .font(Font.custom("Averta", size: 14))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.07, green: 0.07, blue: 0.07))
                .padding(.top, 15)
            Button{
                
            }label: {
                Text("Thử lại")
                    .font(
                        Font.custom("Averta", size: 16)
                            .weight(.bold)
                    )
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                
            }.buttonStyle(BorderedButtonStyle())
                .padding(.top, 25)
                .padding(.horizontal, 20)
            
            
            Button{}label: {
                Text("Quay lại trang chủ")
                    .font(
                        Font.custom("Averta", size: 16)
                            .weight(.bold)
                    )
                    .foregroundColor(Color(red: 0, green: 0.55, blue: 0.27))
            }
            .padding(.top, 30)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 34)
        .padding(.bottom, 50)
        .background(Color.white)
        .cornerRadius(8)
        .padding(.horizontal, 20)
    }
    
    fileprivate func popUpNotFound() -> some View {
        return VStack{
            Text("Khách hàng chưa có thông tin trên hệ thống!")
                .font(
                    Font.custom("Averta", size: 18)
                        .weight(.bold)
                )
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.08, green: 0.07, blue: 0.07))
            
            Text("Vui lòng tiếp tục định danh Khách hàng")
                .font(Font.custom("Averta", size: 14))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.08, green: 0.07, blue: 0.07))
                .padding(.top, 20)
            
            Button{}label: {
                Text("Định danh khách hàng")
                    .font(
                        Font.custom("Averta", size: 16)
                            .weight(.bold)
                    )
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
            }
            .buttonStyle(.bordered)
            .padding(.top, 22)
            Text("hoặc liên hệ với bộ phận support")
                .font(Font.custom("Averta", size: 14))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.08, green: 0.07, blue: 0.07))
                .padding(.top, 30)
            
            Button{}label: {
                HStack{
                    Image("headset_icon")
                        .resizable()
                        .frame(width: 16, height: 16)
                    Text("Hỗ trợ 24/7")
                        .font(
                            Font.custom("Averta", size: 16)
                                .weight(.bold)
                        )
                        .multilineTextAlignment(.center)
                        .foregroundColor(Color(red: 0, green: 0.55, blue: 0.27))
                }
            }
            .buttonStyle(ButtonBorderStyle())
            Button{
                
            }label: {
                Text("Quay lại trang chủ")
                    .font(
                        Font.custom("Averta", size: 16)
                            .weight(.bold)
                    )
                    .foregroundColor(Color(red: 0, green: 0.55, blue: 0.27))
            }
            .padding(.top, 30)
        }
        .padding(.vertical, 40)
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(8)
        .padding(.horizontal, 20)
    }
    
    fileprivate func popUpSupport() -> some View {
        return VStack{
            Text("Trung tâm trợ giúp")
              .font(
                Font.custom("Averta", size: 22)
                  .weight(.bold)
              )
              .foregroundColor(Color(red: 0, green: 0.55, blue: 0.27))
            
            Group {
                ItemSupportRow(title: "OCB Hotline", value: "0989.475.895", icon: .init("headset_icon"))
                ItemSupportRow(title: "OCB Hotline", value: "0989.475.895", icon: .init("headset_icon"))
                ItemSupportRow(title: "OCB Hotline", value: "0989.475.895", icon: .init("headset_icon"))
            }
            
            Button{}label: {
                Text("Quay lại trang chủ")
                  .font(
                    Font.custom("Averta", size: 16)
                      .weight(.bold)
                  )
                  .multilineTextAlignment(.center)
                  .foregroundColor(.white)
            }
            .buttonStyle(.bordered)
            .padding(.top, 40)
        }
        .padding(.bottom, 40)
        .padding(.top, 80)
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(8)
        .padding(.horizontal, 20)
        .overlay(
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 100, height: 100)
              .background(.white)
              .cornerRadius(100)
              .overlay(
                RoundedRectangle(cornerRadius: 100)
                  .inset(by: 2.5)
                  .stroke(Color(red: 0, green: 0.55, blue: 0.31), lineWidth: 5)
                  .overlay(
                    Image("headset_icon")
                    .frame(width: 60, height: 60)
                  )
              ).padding(.top, -40), alignment: .top
        )
    }
    
    var body: some View {
        VStack{
            ItemStatusVerifyView(isValid: true, title: "Xác thực khuôn mặt hợp lệ!")
            
            ItemStatusVerifyView(isValid: false, title: "Xác thực khuôn mặt không hợp lệ!")
            
            HStack{
                ImageItermView(title: "Ảnh trong CSDL")
                ImageItermView(title: "Ảnh hiện tại")
            }
            
            CustomerLabel(name: "NGUYỄN THỊ A", description: "Khách hàng cá nhân")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ItemSupportRow: View {
    var title: String
    var value: String
    var icon: Image
    var body: some View {
        VStack{
            HStack(spacing: 15){
                Image("headset_icon")
                    .resizable()
                .frame(width: 30, height: 30)
                VStack(alignment: .leading, spacing: 8){
                    Text(title)
                      .font(
                        Font.custom("Averta", size: 14)
                          .weight(.semibold)
                      )
                      .foregroundColor(Color(red: 0.19, green: 0.19, blue: 0.19))
                    Text(value)
                      .font(
                        Font.custom("Averta", size: 18)
                          .weight(.bold)
                      )
                      .kerning(0.9)
                      .foregroundColor(.black)
                }
                Spacer()
            }
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: .infinity, height: 1)
              .background(Color(red: 0.91, green: 0.91, blue: 0.91))
        }
        .padding(.horizontal, 25)
    }
}

struct ItemStatusVerifyView: View {
    var isValid: Bool
    var title: String
    var body: some View{
        ZStack {
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 295, height: 42)
              .background(Color(hex: isValid ? 0xF4FFFA : 0xFFF4F4))
              .cornerRadius(5)
              .overlay(
                RoundedRectangle(cornerRadius: 5)
                  .inset(by: 0.5)
                  .stroke(Color(hex: isValid ? 0xD8FAEB :  0xFFDBDB), lineWidth: 1)
              )
            HStack{
                Image(isValid ? "check_icon" : "warning_icon")
                    .resizable()
                .frame(width: 20, height: 20)
                Text(title)
                  .font(
                    Font.custom("Averta", size: 14)
                      .weight(.bold)
                  )
                  .multilineTextAlignment(.center)
                  .foregroundColor(Color(hex: isValid ? 0x008C4F : 0xF22222))
            }
        }
    }
}

struct ImageItermView: View {
    var title: String
    var body: some View {
        ZStack(alignment: .bottom){
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 134, height: 168)
              .background(
                Image("image_demo")
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .frame(width: 134, height: 168)
                  .clipped()
              )
              .cornerRadius(5)
            
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 134, height: 24)
              .background(Color(red: 0, green: 0.55, blue: 0.31))
              .cornerRadius(5)
            Text(title)
              .font(
                Font.custom("Averta", size: 13)
                  .weight(.semibold)
              )
              .multilineTextAlignment(.center)
              .foregroundColor(.white)
              .padding(.vertical, 5)
        }
    }
}


struct ButtonBorderStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.vertical, 15)
            .overlay(
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 275, height: 46)
                    .background(.clear)
                    .cornerRadius(5)
                    .shadow(color: Color(red: 0, green: 0.55, blue: 0.27).opacity(0.05), radius: 2, x: 2, y: 3)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .inset(by: 0.5)
                            .stroke(Color(red: 0, green: 0.55, blue: 0.27), lineWidth: 1)
                    ))
    }
    
}

struct CustomerLabel: View {
    var name: String
    var description: String
    var body: some View {
        VStack(spacing: 10){
            Text(name)
              .font(
                Font.custom("Averta", size: 16)
                  .weight(.bold)
              )
              .foregroundColor(Color(red: 0, green: 0.55, blue: 0.27))
            Text(description)
              .font(Font.custom("Averta", size: 13))
              .foregroundColor(Color(red: 0.19, green: 0.19, blue: 0.19))
        }
    }
}


extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: alpha
        )
    }
}
