//
//  MRActivitiIndicator.swift
//  ui-kit-demo
//
//  Created by Phạm Công on 12/09/2023.
//

import UIKit

class MRActivityIndicator: UIView {
    static var shared = MRActivityIndicator()
    private convenience init() {
        self.init(frame: UIScreen.main.bounds)
    }
    
    private var spinnerBehavior: UIDynamicItemBehavior?
    private var animator: UIDynamicAnimator?
    private var imageView: UIImageView?
    private var centerImageView: UIImageView?
    private var loaderImageName = ""
    private var title: String = ""
        
    func show(with image: String = "elipse_animation", title: String = "") {
        loaderImageName = image
        self.title = title
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {[weak self] in
            if self?.imageView == nil {
                self?.setupView()
                DispatchQueue.main.async {[weak self] in
                    self?.showLoadingActivity()
                }
            }
        }
    }
    
    func hide() {
        DispatchQueue.main.async {[weak self] in
            self?.stopAnimation()
        }
    }
    
    private func setupView() {
        center = CGPoint(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
        autoresizingMask = [.flexibleTopMargin, .flexibleLeftMargin, .flexibleBottomMargin, .flexibleRightMargin]
        
        let theImage = UIImage(named: loaderImageName)
        imageView = UIImageView(image: theImage)
        imageView?.frame = CGRect(x: self.center.x - 34, y: self.center.y - 34, width: 68, height: 68)
        
        let centerImage = UIImage(named: "ocb-coin-logo")
        
        centerImageView = UIImageView(image: centerImage)
        centerImageView?.frame = CGRect(x: self.center.x - 14, y: self.center.y - 14, width: 28, height: 28)
        var itemms: [UIDynamicItem] = []
        if let imageView = imageView {
            itemms.append(imageView)
            
        }
        
        if let centerImageView = self.centerImageView {
            itemms.append(centerImageView)
        }
        
        self.spinnerBehavior = UIDynamicItemBehavior(items: itemms)
        animator = UIDynamicAnimator(referenceView: self)
        let titleLabel = UILabel()
        titleLabel.text = self.title
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        titleLabel.font = .systemFont(ofSize: 16)
        titleLabel.textColor = .red
        
        
    }
    
    private func showLoadingActivity() {
        if let imageView = imageView, let centerImageView = self.centerImageView {
            addSubview(imageView)
            addSubview(centerImageView)
            startAnimation()
            UIApplication.shared.windows.first?.addSubview(self)
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
    }
    
    private func startAnimation() {
        guard let imageView = imageView,
              let spinnerBehavior = spinnerBehavior,
              let animator = animator else { return }
        if !animator.behaviors.contains(spinnerBehavior) {
            spinnerBehavior.addAngularVelocity(10.0, for: imageView)
            animator.addBehavior(spinnerBehavior)
        }
        
    }
    
    private func stopAnimation() {
        animator?.removeAllBehaviors()
        imageView?.removeFromSuperview()
        imageView = nil
        self.removeFromSuperview()
        UIApplication.shared.endIgnoringInteractionEvents()
    }
}
